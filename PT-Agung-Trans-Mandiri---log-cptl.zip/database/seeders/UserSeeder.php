<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'Admin',
            'email' => 'abdullah.ivan@yahoo.com',
            'password' => bcrypt('admin'),
            'role' => 'admin',
            'status' => 'active'
        ]);
        User::create([
            'name' => 'courier 1',
            'email' => 'courier1@gmail.com',
            'password' => bcrypt('courier1'),
            'role' => 'courier',
            'status' => 'active'
        ]);
        User::create([
            'name' => 'courier 2',
            'email' => 'courier2@gmail.com',
            'password' => bcrypt('courier2'),
            'role' => 'courier',
            'status' => 'active'
        ]);
        User::create([
            'name' => 'courier 3',
            'email' => 'courier3@gmail.com',
            'password' => bcrypt('courier3'),
            'role' => 'courier',
            'status' => 'inactive'
        ]);
    }
}
