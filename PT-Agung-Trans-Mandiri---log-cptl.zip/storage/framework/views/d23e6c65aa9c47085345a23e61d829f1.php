<div class="app-header">
    <div class="app-header-left">
        <span class="app-icon"></span>
        <p class="app-name">Agung Trans Mandiri</p>
    </div>
    <div class="app-header-right">
        <div class="dropdown">
            <button class="profile-btn">
                <?php if(auth()->user()->image == 'no picture'): ?>
                    <img src="<?php echo e(url('asset/account.png')); ?>" />
                <?php else: ?>
                    <img src="<?php echo e(url('asset/profile-image'.auth()->user()->image)); ?>" alt="">
                <?php endif; ?>
                <span><?php echo e(old('name', Auth::user()->name)); ?></span>
            </button>
            <div class="dropdown-content">
                <a href="/logout">Log Out</a>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\naufaly\Documents\GitHub\PT-Agung-Trans-Mandiri---log-cptl\resources\views/partial/header.blade.php ENDPATH**/ ?>