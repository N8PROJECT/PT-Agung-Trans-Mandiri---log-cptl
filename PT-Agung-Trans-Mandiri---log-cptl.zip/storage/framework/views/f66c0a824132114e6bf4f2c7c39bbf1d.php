

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/report-pengiriman.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="projects-section">
        <div class="projects-section-header">
            <p>Report</p>
        </div>
        <div class="form-container">
            <form action="/export-admin" method="GET">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date">

                <label for="end_date">End Date:</label>
                <input type="date" id="end_date" name="end_date">

                <label for="User">User:</label>
                <select name="kurir" id="" class="select-box">
                    <?php $__currentLoopData = $kurir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kr->id); ?>"><?php echo e($kr->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <button type="submit">Export Data</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\naufaly\Documents\GitHub\PT-Agung-Trans-Mandiri---log-cptl\resources\views/page/admin/report-pengiriman.blade.php ENDPATH**/ ?>