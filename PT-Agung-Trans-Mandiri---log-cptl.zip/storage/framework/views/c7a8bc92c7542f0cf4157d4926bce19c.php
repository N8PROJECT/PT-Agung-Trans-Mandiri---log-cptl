

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/users.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="projects-section">
        <div class="projects-section-header">
            <p>User Administration</p>
        </div>
        <div class="wrapper">
            <a href="#popup1">
                <button class="add-data-btn">
                    <span class="add-icon">+</span> Add Data
                </button>
            </a>
        </div>
        <div id="popup1" class="overlay">
            <div class="popup">
                <h2>Add User</h2>
                <a class="close" href="#">&times;</a>
                <div class="content">
                    <form action="/add-user" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name">
                    
                        <label for="email">Email</label>
                        <input type="text" id="email" name="email">

                        <label for="password">Password</label>
                        <input type="password" id="password" name="password">

                        <label for="status">Status</label>
                        <select name="status" id="status">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>

                        <label for="role">Role</label>
                        <select name="role" id="role">
                            <option value="admin">admin</option>
                            <option value="courier">courier</option>
                        </select>

                        <input type="submit" value="Submit">
                    </form>
                </div>
            </div>
        </div>
        <div class="filter-section">
            <label for="filter">Filter by Role:</label>
            <select name="filter" id="filter">
                <option value="all">All</option>
                <option value="admin">Admin</option>
                <option value="courier">Courier</option>
            </select>
        </div>
        <div class="projects-section-line">
            <div class="table-responsive-vertical shadow-z-1">
                <!-- Table starts here -->
                <table id="table" class="table table-hover table-mc-light-blue">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Role</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="user-row" data-role="<?php echo e($user->role); ?>">
                                <td data-title="No"><?php echo e($index +1); ?></td>
                                <td data-title="Name"><?php echo e($user->name); ?></td>
                                <td data-title="Email"><?php echo e($user->email); ?></td>
                                <td data-title="Status"><?php echo e($user->status); ?></td>
                                <td data-title="Role"><?php echo e($user->role); ?></td>
                                <td data-title="Edit">
                                    <div id="wrapper">
                                        <a href="#popup<?php echo e($user->id); ?>">
                                            <button class="edit">
                                                Edit
                                            </button>
                                        </a>
                                    </div>
                                    <div id="popup<?php echo e($user->id); ?>" class="overlay">
                                        <div class="popup">
                                            <h2>Edit User</h2>
                                            <a class="close" href="#">&times;</a>
                                            <div class="content">
                                                
                                                <form action="/edit-user" method="post" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <input id="id" type="text" name="id" value="<?php echo e($user->id); ?>" hidden>

                                                    <label for="name">Name</label>
                                                    <input type="text" id="name" name="name" value="<?php echo e($user->name); ?>">
                                                
                                                    <label for="email">Email</label>
                                                    <input type="text" id="email" name="email" value="<?php echo e($user->email); ?>">

                                                    <label for="password">Password</label>
                                                    <input type="password" id="password" name="password" value="<?php echo e($user->password); ?>">

                                                    <label for="status">Status</label>
                                                    <select name="status" id="status">
                                                        <option value="active" <?php echo e($user->status === 'active' ? 'selected' : ''); ?>>Active</option>
                                                        <option value="inactive" <?php echo e($user->status === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                                    </select>

                                                    <label for="role">Role</label>
                                                    <select name="role" id="role">
                                                        <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>admin</option>
                                                        <option value="courier" <?php echo e($user->role === 'courier' ? 'selected' : ''); ?>>courier</option>
                                                    </select>

                                                    <input type="submit" value="Update">
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td data-title="Delete">
                                    <form action="/delete-user/<?php echo e($user->id); ?>" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="delete">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const filterSelect = document.getElementById('filter');

            filterSelect.addEventListener('change', function () {
                const selectedRole = filterSelect.value;
                const users = document.querySelectorAll('.user-row');

                users.forEach(function (user) {
                    if (selectedRole === 'all' || user.dataset.role === selectedRole) {
                        user.style.display = 'table-row';
                    } else {
                        user.style.display = 'none';
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\naufaly\Documents\GitHub\PT-Agung-Trans-Mandiri---log-cptl\resources\views/page/admin/users.blade.php ENDPATH**/ ?>