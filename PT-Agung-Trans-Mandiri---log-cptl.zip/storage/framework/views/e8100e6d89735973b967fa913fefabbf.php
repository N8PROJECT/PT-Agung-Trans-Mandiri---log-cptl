

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/courier/rekap_pengiriman.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="projects-section">
        <div class="projects-section-header">
            <p>Report</p>
        </div>
        <div class="form-container">
            <form action="/export" method="GET">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date">
    
                <label for="end_date">End Date:</label>
                <input type="date" id="end_date" name="end_date">
    
                <button type="submit">Export Data</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\naufaly\Documents\GitHub\PT-Agung-Trans-Mandiri---log-cptl\resources\views/page/courier/rekap_pengiriman.blade.php ENDPATH**/ ?>