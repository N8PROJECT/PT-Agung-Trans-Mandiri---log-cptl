

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/courier/document_delivery.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="projects-section">
        <div class="projects-section-header">
            <p>Pengiriman Dokumen</p>
        </div>
        <div class="wrapper">
            <a href="#popup1">
                <button class="add-data-btn">
                    <span class="add-icon">+</span> Add Data
                </button>
            </a>
        </div>
        <div id="popup1" class="overlay">
            <div class="popup">
                <h2>Add Data</h2>
                <a class="close" href="#">&times;</a>
                <div class="content">
                    <form action="/add-delivery" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="area">Area</label>
                        <input type="text" id="area" name="area">
                    
                        <label for="tanggal-kirim">Tanggal Kirim</label>
                        <input type="date" id="tanggal-kirim" name="tanggal_kirim">

                        <label for="pengirim">Pengirim</label>
                        <input type="text" id="pengirim" name="pengirim">
                        
                        <label for="cabang_pengirim">Cabang Pengirim</label>
                        <input type="text" id="cabang_pengirim" name="cabang_pengirim" required>

                        <label for="tujuan_dokumen">Tujuan Dokumen</label>
                        <input type="text" id="tujuan_dokumen" name="tujuan_dokumen" required>

                        <label for="cabang_tujuan">Cabang Tujuan</label>
                        <select name="cabangtujuan" id="cabang_tujuan">
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <label for="kota">Kota</label>
                        <input type="text" id="kota" name="kota" required>

                        <label for="jenis_kiriman">Jenis Kiriman</label>
                        <input type="text" id="jenis_kiriman" name="jenis_kiriman" required>

                        <label for="nama_penerima">Nama Penerima</label>
                        <input type="text" id="nama_penerima" name="nama_penerima" required>

                        <label for="tanggal_terima">Tanggal Terima</label>
                        <input type="date" id="tanggal_terima" name="tanggal_terima" required>
                      
                        <input type="submit" value="Submit">
                    </form>
                </div>
            </div>
        </div>
        <div class="container">
            <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <div class="delivery-item">
                    <div><strong>Area</strong>: <?php echo e($delivery->area); ?></div>
                    <div><strong>Tanggal Kirim</strong>: <?php echo e($delivery->tanggal_kirim); ?></div>
                    <div><strong>Pengirim</strong>: <?php echo e($delivery->pengirim); ?></div>
                    <div><strong>Cabang Pengirim</strong>: <?php echo e($delivery->cabang_pengirim); ?></div>
                    <div><strong>Tujuan Dokumen</strong>: <?php echo e($delivery->tujuan_dokumen); ?></div>
                    <div><strong>Cabang Tujuan</strong>: <?php echo e($delivery->capital_branch->name); ?></div>
                    <div><strong>Kota</strong>: <?php echo e($delivery->kota); ?></div>
                    <div><strong>Jenis Kiriman</strong>: <?php echo e($delivery->jenis_kiriman); ?></div>
                    <div><strong>Nama Penerima</strong>: <?php echo e($delivery->nama_penerima); ?></div>
                    <div><strong>Tanggal Terima</strong>: <?php echo e($delivery->tanggal_terima); ?></div>
                    <div><strong>Nama Kurir</strong>: <?php echo e($delivery->user->name); ?></div>
                    <div class="button-delivery">
                        <div id="wrapper">
                            <a href="#popup2">
                                <button class="edit">
                                    Edit
                                </button>
                            </a>
                        </div>
                        <div id="popup2" class="overlay">
                            <div class="popup">
                                <h2>Edit Delivery</h2>
                                <a class="close" href="#">&times;</a>
                                <div class="content">
                                    <form action="/edit-delivery" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <input id="id" type="text" name="id" value="<?php echo e($delivery->id); ?>" hidden>

                                        <label for="area">Area</label>
                                        <input type="text" id="area" name="area" value="<?php echo e($delivery->area); ?>">
                                    
                                        <label for="tanggal-kirim">Tanggal Kirim</label>
                                        <input type="date" id="tanggal-kirim" name="tanggal_kirim" value="<?php echo e($delivery->tanggal_kirim); ?>">

                                        <label for="pengirim">Pengirim</label>
                                        <input type="text" id="pengirim" name="pengirim" value="<?php echo e($delivery->pengirim); ?>">
                                        
                                        <label for="cabang_pengirim">Cabang Pengirim</label>
                                        <input type="text" id="cabang_pengirim" name="cabang_pengirim" value="<?php echo e($delivery->cabang_pengirim); ?>">

                                        <label for="tujuan_dokumen">Tujuan Dokumen</label>
                                        <input type="text" id="tujuan_dokumen" name="tujuan_dokumen" value="<?php echo e($delivery->tujuan_dokumen); ?>">

                                        <label for="cabang_tujuan">Cabang Tujuan</label>
                                        <select name="cabangtujuan" id="cabang_tujuan">
                                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        <label for="kota">Kota</label>
                                        <input type="text" id="kota" name="kota" value="<?php echo e($delivery->kota); ?>">

                                        <label for="jenis_kiriman">Jenis Kiriman</label>
                                        <input type="text" id="jenis_kiriman" name="jenis_kiriman" value="<?php echo e($delivery->jenis_kiriman); ?>">

                                        <label for="nama_penerima">Nama Penerima</label>
                                        <input type="text" id="nama_penerima" name="nama_penerima" value="<?php echo e($delivery->nama_penerima); ?>">

                                        <label for="tanggal_terima">Tanggal Terima</label>
                                        <input type="date" id="tanggal_terima" name="tanggal_terima" value="<?php echo e($delivery->tanggal_terima); ?>">
                                      
                                        <input type="submit" value="Update">
                                    </form>
                                </div>
                            </div>
                        </div>
                        <form action="/delete-delivery/<?php echo e($delivery->id); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button class="delete">
                                Delete
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('script/delivery.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\naufaly\Documents\GitHub\PT-Agung-Trans-Mandiri---log-cptl\resources\views/page/courier/document_delivery.blade.php ENDPATH**/ ?>