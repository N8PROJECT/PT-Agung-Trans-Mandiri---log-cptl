

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/capital_branch.css')); ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="projects-section">
        <div class="projects-section-header">
            <p>Capital Branch</p>
        </div>
        <div id="wrapper">
            <p><a class="button" href="#popup1">+ Add Branch</a></p>
        </div>
        <div id="popup1" class="overlay">
            <div class="popup">
                <h2>Add Capital Branch</h2>
                <a class="close" href="#">&times;</a>
                <div class="content">
                    <form action="/add-branch" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="lokasi">Lokasi</label>
                        <input type="text" id="lokasi" name="name">
                    
                        <label for="kode-cabang">Kode Cabang</label>
                        <input type="text" id="kode-cabang" name="code">
                      
                        <input type="submit" value="Submit">
                    </form>
                </div>
            </div>
        </div>
        <div class="projects-section-line">
            <div class="table-responsive-vertical shadow-z-1">
                <!-- Table starts here -->
                <table id="table" class="table table-hover table-mc-light-blue">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Code</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $capital_branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-title="No"><?php echo e($index +1); ?></td>
                                <td data-title="Name"><?php echo e($cp->name); ?></td>
                                <td data-title="Email"><?php echo e($cp->code); ?></td>
                                <td data-title="Edit">
                                    <div id="wrapper">
                                        <a href="#popup<?php echo e($cp->id); ?>">
                                            <button class="edit">
                                                Edit
                                            </button>
                                        </a>
                                    </div>
                                    <div id="popup<?php echo e($cp->id); ?>" class="overlay">
                                        <div class="popup">
                                            <h2>Edit Capital Branch</h2>
                                            <a class="close" href="#">&times;</a>
                                            <div class="content">
                                                <form action="/edit-branch" method="post" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <input id="id" type="text" name="id" value="<?php echo e($cp->id); ?>" hidden>

                                                    <label for="lokasi">Lokasi</label>
                                                    <input type="text" id="lokasi" name="name" value="<?php echo e($cp->name); ?>">
                                                
                                                    <label for="kode-cabang">Kode Cabang</label>
                                                    <input type="text" id="kode-cabang" name="code" value="<?php echo e($cp->code); ?>">
                                                  
                                                    <input type="submit" value="Update">
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td data-title="Delete">
                                    <form action="/delete-branch/<?php echo e($cp->id); ?>" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="delete">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\naufaly\Documents\GitHub\PT-Agung-Trans-Mandiri---log-cptl\resources\views/page/admin/capital_branch.blade.php ENDPATH**/ ?>