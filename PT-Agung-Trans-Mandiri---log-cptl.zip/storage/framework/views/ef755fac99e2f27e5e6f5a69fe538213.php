

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/courier/courier_dashboard.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="projects-section">
        <div class="projects-section-header">
            <p>Dashboard</p>
            <p class="time"><?php echo e($formattedDate); ?></p>
        </div>
    <div class="projects-section-line">
        <div class="projects-status">
            <div class="item-status">
                <span class="status-number"><?php echo e($totalDeliveriesThisMonth); ?></span>
                <span class="status-type">Total Transaction / Month</span>
            </div>
            <div class="item-status">
                <span class="status-number"><?php echo e($totalDeliveriesThisYear); ?></span>
                <span class="status-type">Total Transaction / Year</span>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\naufaly\Documents\GitHub\PT-Agung-Trans-Mandiri---log-cptl\resources\views/page/courier/courier_dashboard.blade.php ENDPATH**/ ?>